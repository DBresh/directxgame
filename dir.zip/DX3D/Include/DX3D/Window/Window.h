#pragma once
#include <DX3D/Core/Base.h>
#include <DX3D/Core/Common.h>

namespace dx3d
{

	class Window: public Base
	{
	public:
		explicit Window(const WindowDesc& desc);
		virtual ~Window() override;
		void* getHWND() const noexcept { return m_handle; }

		virtual void onResize(int width, int height);
		virtual void onEnterSizeMove() {}
		virtual void onExitSizeMove() {}

	protected:
		void* m_handle{};
		Rect m_size{};
	};
}

