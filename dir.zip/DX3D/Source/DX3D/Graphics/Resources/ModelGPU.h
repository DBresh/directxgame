#pragma once
#include <vector>
#include <memory>
#include <DX3D/Graphics/Resources/Mesh.h>
#include <DX3D/Graphics/Resources/Material.h>
#include <DX3D/Graphics/Resources/ModelData.h>

namespace dx3d
{
    struct SubMesh
    {
        std::shared_ptr<Mesh> mesh;   // ������� GPU-���
        int materialIndex = -1;       // ������ �������� � ModelData/MaterialLoader
        unsigned startIndex = 0;
        unsigned indexCount = 0;
    };

    struct ModelGPU
    {
        std::shared_ptr<Mesh> mesh;

        std::vector<SubMesh> submeshes;

        std::vector<Material> materials;
        std::vector<MaterialGroup> materialGroups;
        AABB boundingBox;
    };
}
