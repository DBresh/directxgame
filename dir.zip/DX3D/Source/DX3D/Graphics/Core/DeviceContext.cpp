#include <DX3D/Graphics/Core/DeviceContext.h>
#include <DX3D/Graphics/Core/SwapChain.h>
#include <DX3D/Graphics/Core/GraphicsPipelineState.h>
#include <DX3D/Graphics/Buffers/VertexBuffer.h>
#include <DX3D/Graphics/Buffers/IndexBuffer.h>
#include <DX3D/Graphics/Buffers/ConstantBuffer.h>
#include <DX3D/Graphics/Buffers/StructuredBuffer.h>
#include <DX3D/Graphics/Core/GraphicsDevice.h>
#include <DX3D/Graphics/Buffers/InstanceBuffer.h>
#include <DirectXMath.h>

namespace dx3d
{
	DeviceContext::DeviceContext(const GraphicsResourceDesc& gDesc) : GraphicsResource(gDesc)
	{
		DX3D_GRAPHICS_LOG_THROW_ON_FAIL(m_device.CreateDeferredContext(0, &m_context), "CreateDeferredContext failed.");
	}

	DeviceContext::DeviceContext(ID3D11DeviceContext* context, std::shared_ptr<GraphicsDevice> device)
		: GraphicsResource(GraphicsResourceDesc{
			device->getDesc().base,          // Pass the BaseDesc
			device,                          // The shared_ptr
			*device->getD3D11Device(),       // Dereference to get ID3D11Device&
			*device->getDXGIFactory()        // Dereference to get IDXGIFactory&
			}),
		m_context(context)
	{
		// The m_context is initialized in the initializer list above
	}

	void DeviceContext::clearAndSetBackBuffer(const SwapChain& swapChain, const DirectX::XMFLOAT4& color)
	{
		float fColor[] = { color.x, color.y, color.z, color.w };

		m_context->ClearRenderTargetView(swapChain.m_rtv.Get(), fColor);
		m_context->ClearDepthStencilView(swapChain.m_dsv.Get(),
			D3D11_CLEAR_DEPTH, 1.0f, 0);

		auto rtv = swapChain.m_rtv.Get();
		auto dsv = swapChain.m_dsv.Get();
		m_context->OMSetRenderTargets(1, &rtv, dsv);
	}


	void DeviceContext::setGraphicsPipelineState(const GraphicsPipelineState& pipeline)
	{
		m_context->IASetInputLayout(pipeline.m_layout.Get());
		m_context->VSSetShader(pipeline.m_vs.Get(), nullptr, 0);
		m_context->PSSetShader(pipeline.m_ps.Get(), nullptr, 0);
		m_context->OMSetDepthStencilState(pipeline.m_depthStencilState.Get(), 0);
		m_context->RSSetState(pipeline.getRasterizerState());
	}

	void DeviceContext::setVertexBuffer(const VertexBuffer& buffer)
	{
		auto buf = buffer.m_buffer.Get();
		auto stride = buffer.m_vertexSize;
		auto offset = 0u;
		m_context->IASetVertexBuffers(0, 1, &buf, &stride, &offset);
	}

	void DeviceContext::setIndexBuffer(const IndexBuffer& buffer)
	{
		m_context->IASetIndexBuffer(buffer.m_buffer.Get(), buffer.m_format, 0);
	}

	void DeviceContext::drawIndexedTriangleList(unsigned int indexCount, unsigned int startIndexLocation, unsigned int baseVertexLocation)
	{
		m_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
		m_context->DrawIndexed(indexCount, startIndexLocation, baseVertexLocation);
	}

	void DeviceContext::drawIndexedLineList(unsigned int indexCount, unsigned int startIndexLocation, unsigned int baseVertexLocation)
	{
		m_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);
		m_context->DrawIndexed(indexCount, startIndexLocation, baseVertexLocation);
	}

	void DeviceContext::setViewportSize(const Rect& size)
	{
		D3D11_VIEWPORT vp{};
		vp.Width = static_cast<float>(size.width);
		vp.Height = static_cast<float>(size.height);
		vp.MinDepth = 0.0f;
		vp.MaxDepth = 1.0f;

		m_context->RSSetViewports(1, &vp);
	}

	void DeviceContext::drawTriangleList(unsigned int vertexCount, unsigned int startVertexLocation)
	{
		m_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
		m_context->Draw(vertexCount, startVertexLocation);
	}

	void DeviceContext::setVSConstantBuffer(const ConstantBuffer& buffer, unsigned int slot)
	{
		ID3D11Buffer* b = buffer.m_buffer.Get();
		m_context->VSSetConstantBuffers(slot, 1, &b);
	}

	void DeviceContext::setPSConstantBuffer(const ConstantBuffer& buffer, unsigned int slot)
	{
		ID3D11Buffer* b = buffer.m_buffer.Get();
		m_context->PSSetConstantBuffers(slot, 1, &b);
	}

	void DeviceContext::updateConstantBuffer(const ConstantBuffer& buffer, const void* data, size_t dataSize)
	{
		if (data == nullptr || dataSize == 0) return;

		if (dataSize > buffer.getBufferSize())
			DX3D_LOG_THROW_ERROR("updateConstantBuffer: dataSize > buffer size");

		D3D11_MAPPED_SUBRESOURCE mappedResource;
		HRESULT hr = m_context->Map(buffer.m_buffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
		if (SUCCEEDED(hr))
		{
			memcpy(mappedResource.pData, data, dataSize);
			m_context->Unmap(buffer.m_buffer.Get(), 0);
		}
		else
		{
			DX3D_GRAPHICS_LOG_THROW_ON_FAIL(hr, "Map failed for constant buffer update.");
		}
	}

	void dx3d::DeviceContext::setPSTexture(ID3D11ShaderResourceView* srv, unsigned int slot)
	{
		m_context->PSSetShaderResources(slot, 1, &srv);
	}

	void dx3d::DeviceContext::setPSSampler(ID3D11SamplerState* sampler, unsigned int slot)
	{
		m_context->PSSetSamplers(slot, 1, &sampler);
	}

	void DeviceContext::setStructuredBuffer(const StructuredBuffer& buffer, unsigned int slot)
	{
		ID3D11ShaderResourceView* srv = buffer.getSRV();
		m_context->PSSetShaderResources(slot, 1, &srv);
	}

	void DeviceContext::setDepthTarget(ID3D11DepthStencilView* dsv)
	{
		m_context->OMSetRenderTargets(0, nullptr, dsv);
	}

	void DeviceContext::clearDepth(ID3D11DepthStencilView& dsv)
	{
		m_context->ClearDepthStencilView(&dsv, D3D11_CLEAR_DEPTH, 1.0f, 0);
	}

	void DeviceContext::setVertexShader(ID3D11VertexShader* vs)
	{
		m_context->VSSetShader(vs, nullptr, 0);
	}

	void DeviceContext::setPixelShader(ID3D11PixelShader* ps)
	{
		m_context->PSSetShader(ps, nullptr, 0);
	}
	
	void DeviceContext::setDepthTargetArraySlice(ID3D11DepthStencilView* dsv)
	{
		m_context->OMSetRenderTargets(0, nullptr, dsv);
	}

	void DeviceContext::setRenderTarget(const SwapChain& swapChain)
	{
		auto rtv = swapChain.m_rtv.Get();
		auto dsv = swapChain.m_dsv.Get();
		m_context->OMSetRenderTargets(1, &rtv, dsv);
	}

	void DeviceContext::setInstanceBuffer(const InstanceBuffer& buffer, unsigned int slot)
	{
		unsigned int stride = buffer.getStride();
		unsigned int offset = 0;
		ID3D11Buffer* buf = buffer.getBuffer();
		m_context->IASetVertexBuffers(slot, 1, &buf, &stride, &offset);
	}

	void DeviceContext::drawIndexedInstanced(unsigned int indexCountPerInstance, unsigned int instanceCount, unsigned int startIndexLocation, int baseVertexLocation, unsigned int startInstanceLocation)
	{
		m_context->DrawIndexedInstanced(indexCountPerInstance, instanceCount, startIndexLocation, baseVertexLocation, startInstanceLocation);
	}

	D3D11_MAPPED_SUBRESOURCE DeviceContext::mapBuffer(ID3D11Buffer* buffer)
	{
		D3D11_MAPPED_SUBRESOURCE mappedResource = {};
		m_context->Map(buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
		return mappedResource;
	}

	void DeviceContext::unmapBuffer(ID3D11Buffer* buffer)
	{
		m_context->Unmap(buffer, 0);
	}
}